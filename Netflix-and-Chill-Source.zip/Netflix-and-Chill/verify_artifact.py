#!/usr/bin/env python3
"""Audit the built plist and optionally verify its guide discovery against live RSS."""
from __future__ import annotations

import base64
from datetime import date
import io
import json
from pathlib import Path
import plistlib
import re
import sys
import urllib.request
from urllib.parse import urlsplit
import xml.etree.ElementTree as ET

from PIL import Image

ROOT = Path(__file__).resolve().parent
PATH = ROOT / 'dist/Netflix-and-Chill-unsigned.shortcut'
data = plistlib.loads(PATH.read_bytes())
actions = data['WFWorkflowActions']
prior, stack, comments = set(), [], []
token_count = 0
card_count = 0
allowed = {'comment', 'downloadurl', 'detect.dictionary', 'getvalueforkey', 'text.match',
           'conditional', 'gettext', 'number', 'setvariable', 'setitemname', 'detect.contacts',
           'choosefromlist', 'properties.contacts', 'openurl', 'exit', 'showresult',
           'repeat.count', 'repeat.each', 'nothing', 'date', 'format.date', 'math', 'rss',
           'properties.articles', 'url', 'showwebpage'}


def check(value):
    global token_count
    if isinstance(value, list):
        for item in value:
            check(item)
    elif isinstance(value, dict):
        if value.get('Type') == 'ActionOutput':
            assert value['OutputUUID'] in prior, ('Missing or forward output', value)
        if value.get('WFSerializationType') == 'WFTextTokenString':
            token_count += 1
            state = value['Value']
            encoded = state['string'].encode('utf-16-le')
            assert state['string'].count('\ufffc') == len(state['attachmentsByRange'])
            for key in state['attachmentsByRange']:
                start, length = map(int, re.findall(r'\d+', key))
                assert length == 1
                assert encoded[start*2:(start+1)*2].decode('utf-16-le') == '\ufffc'
        for item in value.values():
            check(item)


for index, action in enumerate(actions):
    ident = action['WFWorkflowActionIdentifier'].removeprefix('is.workflow.actions.')
    q = action['WFWorkflowActionParameters']
    assert ident in allowed, ident
    assert q['UUID'] not in prior, ('Duplicate UUID', q['UUID'])
    check(q)
    if ident == 'comment':
        comments.append(index)
    if 'WFControlFlowMode' in q:
        mode, group = q['WFControlFlowMode'], q['GroupingIdentifier']
        if mode == 0:
            stack.append((ident, group))
        else:
            assert stack and stack[-1] == (ident, group), ('Unbalanced flow', index)
            if mode == 1:
                assert ident == 'conditional'
            elif mode == 2:
                stack.pop()
            else:
                raise AssertionError(('Unexpected control mode', mode))
    if ident == 'gettext' and isinstance(q['WFTextActionText'], str) and q['WFTextActionText'].startswith('BEGIN:VCARD'):
        cards = q['WFTextActionText'].split('END:VCARD')[:-1]
        routes = []
        for card in cards:
            assert '\nVERSION:3.0\n' in card and '\nFN:' in card and '\nORG:' in card
            route = re.search(r'\nNOTE:([^\n]+)', card).group(1)
            assert route not in routes
            routes.append(route)
            photo = re.search(r'\nPHOTO;ENCODING=b;TYPE=PNG:([^\n]+)', card).group(1)
            image = Image.open(io.BytesIO(base64.b64decode(photo, validate=True)))
            assert image.size == (192, 192) and image.mode == 'RGBA'
            assert image.getpixel((0, 0))[3] == 0
            card_count += 1
    if ident == 'downloadurl':
        assert q['WFHTTPMethod'] == 'GET'
        assert q['WFURL'] == 'https://raw.githubusercontent.com/surfkraken/Netflix-and-Chill/main/latest.json'
    if ident == 'rss':
        assert q['WFRSSItemQuantity'] == 50
    prior.add(q['UUID'])

assert not stack
assert comments == [0]
assert data['WFWorkflowName'] == 'Netflix & Chill'
assert 'Created by SurfKraken' in actions[0]['WFWorkflowActionParameters']['WFCommentActionText']
assert len(actions) < 400
assert sum(a['WFWorkflowActionIdentifier'].endswith('.downloadurl') for a in actions) == 2
assert sum(a['WFWorkflowActionIdentifier'].endswith('.rss') for a in actions) == 1


def resolve_pattern(value, month):
    if isinstance(value, str):
        return value.replace(r'\z', r'\Z')
    state = value['Value']
    result = state['string']
    assert list(state['attachmentsByRange'].values()) == [{'Type': 'Variable', 'VariableName': 'Selected Month'}]
    result = result.replace(r'\Q' + '\ufffc' + r'\E', re.escape(month))
    return result.replace(r'\x{2019}', '\u2019').replace(r'\x27', "'").replace(r'\z', r'\Z')


guide_patterns = []
for index, action in enumerate(actions[:-1]):
    q = action['WFWorkflowActionParameters']
    next_q = actions[index+1]['WFWorkflowActionParameters']
    if action['WFWorkflowActionIdentifier'].endswith('.gettext') and next_q.get('WFVariableName') == 'Guide Title Pattern':
        guide_patterns.append(q['WFTextActionText'])
assert len(guide_patterns) == 4
coming, leaving = [re.compile(resolve_pattern(p, 'November 2026')) for p in guide_patterns[:2]]
assert coming.fullmatch('What’s Coming to Netflix in November 2026')
assert coming.fullmatch("What's Coming to Netflix in November 2026")
assert coming.fullmatch('Full List of What’s Coming to Netflix in November 2026')
assert leaving.fullmatch('What’s Leaving Netflix in November 2026')
for invalid in ('What’s Coming to Netflix UK in November 2026',
                'What’s Coming to Netflix in December 2026',
                'New Anime Coming to Netflix in November 2026',
                'What’s Coming to Netflix in November 2026: UK Edition'):
    assert not coming.fullmatch(invalid), invalid

link_pattern = next(a['WFWorkflowActionParameters']['WFMatchTextPattern'] for a in actions
                    if a['WFWorkflowActionIdentifier'].endswith('.text.match')
                    and isinstance(a['WFWorkflowActionParameters']['WFMatchTextPattern'], str)
                    and 'icloud' in a['WFWorkflowActionParameters']['WFMatchTextPattern'])
link_re = re.compile(link_pattern.replace(r'\z', r'\Z'))
assert link_re.fullmatch('https://www.icloud.com/shortcuts/' + 'a'*32)
for invalid in ('http://www.icloud.com/shortcuts/' + 'a'*32,
                'https://www.icloud.com.evil.test/shortcuts/' + 'a'*32,
                'https://example.com/', 'https://www.icloud.com/shortcuts/too-short',
                'https://www.icloud.com/shortcuts/' + 'a'*32 + '\n'):
    assert not link_re.fullmatch(invalid), invalid

manifest = json.loads((ROOT/'latest.json').read_text())
assert manifest['build'] == 100 and manifest['version'] == '1.0' and manifest['url'] == ''


def evaluate_date_actions(now):
    """Execute the emitted date block, including its actual token links and branch."""
    variables, outputs = {}, {}
    def resolve(value):
        if not isinstance(value, dict):
            return value
        if value.get('WFSerializationType') == 'WFTextTokenString':
            state = value['Value']
            result = state['string']
            for key, ref in sorted(state['attachmentsByRange'].items(), reverse=True):
                start, _ = map(int, re.findall(r'\d+', key))
                units = result.encode('utf-16-le')
                result = (units[:start*2] + str(resolve({'Value': ref})).encode('utf-16-le') + units[(start+1)*2:]).decode('utf-16-le')
            return result
        state = value.get('Value', value)
        if state.get('Type') == 'Variable':
            return variables[state['VariableName']]
        if state.get('Type') == 'ActionOutput':
            return outputs[state['OutputUUID']]
        raise AssertionError(('Unexpected date value', value))
    index = next(i for i, a in enumerate(actions) if a['WFWorkflowActionIdentifier'].endswith('.date')
                 and a['WFWorkflowActionIdentifier'] == 'is.workflow.actions.date')
    while index < len(actions):
        action = actions[index]
        kind = action['WFWorkflowActionIdentifier'].removeprefix('is.workflow.actions.')
        q = action['WFWorkflowActionParameters']
        result = None
        if kind == 'gettext' and isinstance(q['WFTextActionText'], str) and q['WFTextActionText'].startswith('BEGIN:VCARD'):
            break
        if kind == 'date':
            result = now
        elif kind == 'format.date':
            source = resolve(q['WFDate'])
            result = str(source.month if q['WFDateFormat'] == 'M' else source.year)
        elif kind == 'number':
            result = int(resolve(q['WFNumberActionNumber']))
        elif kind == 'math':
            assert q['WFMathOperation'] == '+'
            result = resolve(q['WFInput']) + resolve(q['WFMathOperand'])
        elif kind == 'gettext':
            result = resolve(q['WFTextActionText'])
        elif kind == 'setvariable':
            variables[q['WFVariableName']] = resolve(q['WFInput'])
        elif kind == 'detect.dictionary':
            result = json.loads(resolve(q['WFInput']))
        elif kind == 'getvalueforkey':
            result = resolve(q['WFInput'])[str(resolve(q['WFDictionaryKey']))]
        elif kind == 'conditional':
            if q['WFControlFlowMode'] == 0:
                assert q['WFCondition'] == 2
                source = resolve(q['WFInput']['Variable'])
                if not source > int(resolve(q['WFNumberValue'])):
                    group = q['GroupingIdentifier']
                    index = next(i for i in range(index+1, len(actions))
                        if actions[i]['WFWorkflowActionParameters'].get('GroupingIdentifier') == group
                        and actions[i]['WFWorkflowActionParameters'].get('WFControlFlowMode') == 2)
        elif kind == 'nothing':
            result = None
        else:
            raise AssertionError(('Unexpected date action', kind))
        outputs[q['UUID']] = result
        index += 1
    return variables


for now, expected in [(date(2026, 12, 31), ('December 2026', 'January 2027')),
                      (date(2027, 1, 31), ('January 2027', 'February 2027')),
                      (date(2028, 2, 29), ('February 2028', 'March 2028')),
                      (date(2026, 11, 1), ('November 2026', 'December 2026'))]:
    values = evaluate_date_actions(now)
    assert (values['This Month Label'], values['Next Month Label']) == expected

report = {'result': 'passed', 'actions': len(actions), 'author_comment_only': comments == [0],
          'text_token_states_checked': token_count, 'embedded_cards_checked': card_count,
          'unique_and_prior_action_references': True, 'balanced_control_flow': True,
          'month_rollover_cases': 4, 'monthly_title_fixtures': 'passed',
          'update_link_validation': 'passed', 'native_iphone_execution': 'not performed',
          'unsigned': True, 'live_feeds': 'not requested'}

if '--live' in sys.argv:
    live = []
    now = date.today()
    month_names = ('January February March April May June July August September October November December').split()
    for category, template in [('coming-soon', guide_patterns[0]), ('leaving-soon', guide_patterns[1])]:
        request = urllib.request.Request(f'https://www.whats-on-netflix.com/{category}/feed/',
            headers={'User-Agent': 'Mozilla/5.0', 'Accept': 'application/rss+xml,application/xml;q=0.9,*/*;q=0.8'})
        with urllib.request.urlopen(request, timeout=30) as response:
            items = ET.fromstring(response.read()).findall('.//item')
        for offset in (0, 1):
            month = now.month + offset
            year = now.year
            if month > 12:
                month, year = 1, year+1
            label = f'{month_names[month-1]} {year}'
            pattern = re.compile(resolve_pattern(template, label))
            matches = [i for i in items[:50] if pattern.fullmatch(i.findtext('title') or '')]
            row = {'category': category, 'month': label, 'feed_items': len(items), 'matches': len(matches)}
            if matches:
                item = matches[0]
                url = item.findtext('link') or ''
                assert urlsplit(url).hostname == 'www.whats-on-netflix.com'
                body = item.findtext('{http://purl.org/rss/1.0/modules/content/}encoded') or ''
                row.update(title=item.findtext('title'), url=url,
                           article_images=len(re.findall(r'<img\b', body)))
            live.append(row)
    report['live_feeds'] = live

(ROOT/'dist/verification.json').write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n')
print(json.dumps(report, indent=2, ensure_ascii=False))
