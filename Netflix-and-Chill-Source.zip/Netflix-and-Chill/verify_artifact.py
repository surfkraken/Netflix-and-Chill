#!/usr/bin/env python3
"""Audit the built plist and optionally verify its guide discovery against live RSS."""
from __future__ import annotations

import base64
from datetime import date
import io
import json
from pathlib import Path
import plistlib
import re
import sys
import urllib.request
from urllib.parse import urlsplit
import xml.etree.ElementTree as ET

from PIL import Image
from icu_regex_check import findall as icu_findall

ROOT = Path(__file__).resolve().parent
PATH = ROOT / 'dist/Netflix-and-Chill-unsigned.shortcut'
data = plistlib.loads(PATH.read_bytes())
actions = data['WFWorkflowActions']
prior, stack, comments = set(), [], []
token_count = 0
card_count = 0
allowed = {'comment', 'downloadurl', 'detect.dictionary', 'getvalueforkey', 'text.match',
           'conditional', 'gettext', 'number', 'setvariable', 'setitemname', 'detect.contacts',
           'choosefromlist', 'properties.contacts', 'openurl', 'exit', 'showresult',
           'repeat.count', 'repeat.each', 'nothing', 'date', 'format.date', 'math', 'rss',
           'properties.articles', 'url', 'showwebpage', 'detect.text', 'text.replace',
           'getitemfromlist'}


def check(value):
    global token_count
    if isinstance(value, list):
        for item in value:
            check(item)
    elif isinstance(value, dict):
        if value.get('Type') == 'ActionOutput':
            assert value['OutputUUID'] in prior, ('Missing or forward output', value)
        if value.get('WFSerializationType') == 'WFTextTokenString':
            token_count += 1
            state = value['Value']
            encoded = state['string'].encode('utf-16-le')
            assert state['string'].count('\ufffc') == len(state.get('attachmentsByRange', {}))
            for key in state.get('attachmentsByRange', {}):
                start, length = map(int, re.findall(r'\d+', key))
                assert length == 1
                assert encoded[start*2:(start+1)*2].decode('utf-16-le') == '\ufffc'
        for item in value.values():
            check(item)


for index, action in enumerate(actions):
    ident = action['WFWorkflowActionIdentifier'].removeprefix('is.workflow.actions.')
    q = action['WFWorkflowActionParameters']
    assert ident in allowed, ident
    assert q['UUID'] not in prior, ('Duplicate UUID', q['UUID'])
    check(q)
    if ident == 'comment':
        comments.append(index)
    if 'WFControlFlowMode' in q:
        mode, group = q['WFControlFlowMode'], q['GroupingIdentifier']
        if mode == 0:
            stack.append((ident, group))
        else:
            assert stack and stack[-1] == (ident, group), ('Unbalanced flow', index)
            if mode == 1:
                assert ident == 'conditional'
            elif mode == 2:
                stack.pop()
            else:
                raise AssertionError(('Unexpected control mode', mode))
    if ident == 'gettext' and isinstance(q['WFTextActionText'], str) and q['WFTextActionText'].startswith('BEGIN:VCARD'):
        cards = q['WFTextActionText'].split('END:VCARD')[:-1]
        routes = []
        for card in cards:
            assert '\nVERSION:3.0\n' in card and '\nFN:' in card and '\nORG:' in card
            route = re.search(r'\nNOTE:([^\n]+)', card).group(1)
            assert route not in routes
            routes.append(route)
            photo = re.search(r'\nPHOTO;ENCODING=b;TYPE=PNG:([^\n]+)', card).group(1)
            image = Image.open(io.BytesIO(base64.b64decode(photo, validate=True)))
            assert image.size == (192, 192) and image.mode == 'RGBA'
            assert image.getpixel((0, 0))[3] == 0
            card_count += 1
    if ident == 'downloadurl':
        assert q['WFHTTPMethod'] == 'GET'
        if isinstance(q['WFURL'], str):
            assert q['WFURL'] in ('https://raw.githubusercontent.com/surfkraken/Netflix-and-Chill/main/latest.json',
                                  'https://raw.githubusercontent.com/surfkraken/Netflix-and-Chill/main/netflix-guides.json')
        else:
            assert q['WFHTTPHeaders']['WFSerializationType'] == 'WFDictionaryFieldValue'
            fields = q['WFHTTPHeaders']['Value']['WFDictionaryFieldValueItems']
            headers = {f['WFKey']['Value']['string']: f['WFValue']['Value']['string'] for f in fields}
            assert headers['User-Agent'] == 'Mozilla/5.0' and 'application/rss+xml' in headers['Accept']
    if ident == 'rss':
        assert q['WFRSSItemQuantity'] == 50
    prior.add(q['UUID'])

assert not stack
assert comments == [0]
assert data['WFWorkflowName'] == 'Netflix & Chill'
assert 'Created by SurfKraken' in actions[0]['WFWorkflowActionParameters']['WFCommentActionText']
assert len(actions) < 400
assert sum(a['WFWorkflowActionIdentifier'].endswith('.downloadurl') for a in actions) == 3
assert sum(a['WFWorkflowActionIdentifier'].endswith('.rss') for a in actions) == 0
assert sum(a['WFWorkflowActionIdentifier'].endswith('.properties.articles') for a in actions) == 0
assert sum(a['WFWorkflowActionIdentifier'].endswith('.repeat.each') for a in actions) == 0


def resolve_pattern(value, slug):
    if isinstance(value, str):
        return value.replace(r'\z', r'\Z')
    state = value['Value']
    result = state['string']
    assert len(state['attachmentsByRange']) == 1
    ref = next(iter(state['attachmentsByRange'].values()))
    assert ref['Type'] == 'Variable' and ref['VariableName'] in ('This Month Slug', 'Next Month Slug')
    return result.replace('\ufffc', slug)


from refresh_netflix_guides import parse_feed, merge
arrival = 'https://www.whats-on-netflix.com/coming-soon/whats-coming-to-netflix-in-november-2026/'
departure = 'https://www.whats-on-netflix.com/leaving-soon/whats-leaving-netflix-november-2026/'
def fixture(url):
    return ('<rss><channel><item><title>Any title</title><link>'+url+'</link></item></channel></rss>').encode()
assert parse_feed(fixture(arrival), 'coming') == {'coming:November-2026': arrival}
assert parse_feed(fixture(departure), 'leaving') == {'leaving:November-2026': departure}
assert parse_feed(fixture(departure.replace('netflix-november', 'netflix-in-november')), 'leaving')
cache = json.loads((ROOT/'netflix-guides.json').read_text())
retained = merge(cache, [('coming', None, 'HTTP 503'), ('leaving', None, 'HTTP 403')], 'test-time')
assert retained['guides'] == cache['guides'] and retained['updated_at'] == cache['updated_at']
assert set(retained['errors']) == {'coming', 'leaving'}
assert merge(cache, [('coming', {'coming:January-2027': arrival}, None)], 'new-time')['guides']['leaving:November-2026'] == departure.replace('netflix-november', 'netflix-in-november')

link_pattern = next(a['WFWorkflowActionParameters']['WFMatchTextPattern'] for a in actions
                    if a['WFWorkflowActionIdentifier'].endswith('.text.match')
                    and isinstance(a['WFWorkflowActionParameters']['WFMatchTextPattern'], str)
                    and 'icloud' in a['WFWorkflowActionParameters']['WFMatchTextPattern'])
link_re = re.compile(link_pattern.replace(r'\z', r'\Z'))
assert link_re.fullmatch('https://www.icloud.com/shortcuts/' + 'a'*32)
for invalid in ('http://www.icloud.com/shortcuts/' + 'a'*32,
                'https://www.icloud.com.evil.test/shortcuts/' + 'a'*32,
                'https://example.com/', 'https://www.icloud.com/shortcuts/too-short',
                'https://www.icloud.com/shortcuts/' + 'a'*32 + '\n'):
    assert not link_re.fullmatch(invalid), invalid

manifest = json.loads((ROOT/'latest.json').read_text())
assert manifest['build'] == 100 and manifest['version'] == '1.0' and manifest['url'] == ''
pending = json.loads((ROOT/'dist/release-manifest-pending.json').read_text())
assert pending['build'] == 101 and pending['version'] == '1.1' and pending['url'] == ''


def evaluate_date_actions(now):
    """Execute the emitted date block, including its actual token links and branch."""
    variables, outputs = {}, {}
    def resolve(value):
        if not isinstance(value, dict):
            return value
        if value.get('WFSerializationType') == 'WFTextTokenString':
            state = value['Value']
            result = state['string']
            for key, ref in sorted(state['attachmentsByRange'].items(), reverse=True):
                start, _ = map(int, re.findall(r'\d+', key))
                units = result.encode('utf-16-le')
                result = (units[:start*2] + str(resolve({'Value': ref})).encode('utf-16-le') + units[(start+1)*2:]).decode('utf-16-le')
            return result
        state = value.get('Value', value)
        if state.get('Type') == 'Variable':
            return variables[state['VariableName']]
        if state.get('Type') == 'ActionOutput':
            return outputs[state['OutputUUID']]
        raise AssertionError(('Unexpected date value', value))
    index = next(i for i, a in enumerate(actions) if a['WFWorkflowActionIdentifier'].endswith('.date')
                 and a['WFWorkflowActionIdentifier'] == 'is.workflow.actions.date')
    while index < len(actions):
        action = actions[index]
        kind = action['WFWorkflowActionIdentifier'].removeprefix('is.workflow.actions.')
        q = action['WFWorkflowActionParameters']
        result = None
        if kind == 'gettext' and isinstance(q['WFTextActionText'], str) and q['WFTextActionText'].startswith('BEGIN:VCARD'):
            break
        if kind == 'date':
            result = now
        elif kind == 'format.date':
            source = resolve(q['WFDate'])
            result = str(source.month if q['WFDateFormat'] == 'M' else source.year)
        elif kind == 'number':
            result = int(resolve(q['WFNumberActionNumber']))
        elif kind == 'math':
            assert q['WFMathOperation'] == '+'
            result = int(resolve(q['WFInput'])) + int(resolve(q['WFMathOperand']))
        elif kind == 'text.replace':
            result = re.sub(q['WFReplaceTextFind'], q['WFReplaceTextReplace'], str(resolve(q['WFInput'])))
        elif kind == 'gettext':
            result = resolve(q['WFTextActionText'])
        elif kind == 'setvariable':
            variables[q['WFVariableName']] = resolve(q['WFInput'])
        elif kind == 'detect.dictionary':
            result = json.loads(resolve(q['WFInput']))
        elif kind == 'getvalueforkey':
            result = resolve(q['WFInput'])[str(resolve(q['WFDictionaryKey']))]
        elif kind == 'conditional':
            if q['WFControlFlowMode'] == 0:
                assert q['WFCondition'] == 2
                source = resolve(q['WFInput']['Variable'])
                if not source > int(resolve(q['WFNumberValue'])):
                    group = q['GroupingIdentifier']
                    index = next(i for i in range(index+1, len(actions))
                        if actions[i]['WFWorkflowActionParameters'].get('GroupingIdentifier') == group
                        and actions[i]['WFWorkflowActionParameters'].get('WFControlFlowMode') == 2)
        elif kind == 'nothing':
            result = None
        else:
            raise AssertionError(('Unexpected date action', kind))
        outputs[q['UUID']] = result
        index += 1
    return variables


for now, expected in [(date(2026, 12, 31), ('December 2026', 'January 2027')),
                      (date(2027, 1, 31), ('January 2027', 'February 2027')),
                      (date(2028, 2, 29), ('February 2028', 'March 2028')),
                      (date(2026, 11, 1), ('November 2026', 'December 2026'))]:
    values = evaluate_date_actions(now)
    assert (values['This Month Label'], values['Next Month Label']) == expected


def evaluate_lookup(index_data, key):
    variables = {'Guide URL': '', 'Guide Lookup Key': key, 'Selected Month': key.split(':')[-1],
                 'Guide Lookup Result': 'Guide unavailable'}
    outputs = {}
    def stringify(value):
        if value is None:
            return ''
        return '\n'.join(map(str, value)) if isinstance(value, list) else str(value)
    def resolve(value):
        if not isinstance(value, dict):
            return value
        state = value.get('Value', value)
        if value.get('WFSerializationType') == 'WFTextTokenString':
            result = state['string']
            for key, ref in sorted(state.get('attachmentsByRange', {}).items(), reverse=True):
                start, _ = map(int, re.findall(r'\d+', key))
                units = result.encode('utf-16-le')
                result = (units[:start*2] + stringify(resolve({'Value': ref})).encode('utf-16-le')
                          + units[(start+1)*2:]).decode('utf-16-le')
            return result
        if state.get('Type') == 'Variable':
            return variables.get(state['VariableName'])
        if state.get('Type') == 'ActionOutput':
            return outputs[state['OutputUUID']]
        raise AssertionError(value)
    index = next(i for i,a in enumerate(actions)
        if a['WFWorkflowActionParameters'].get('WFURL') ==
           'https://raw.githubusercontent.com/surfkraken/Netflix-and-Chill/main/netflix-guides.json')
    while index < len(actions):
        action = actions[index]
        q = action['WFWorkflowActionParameters']
        kind = action['WFWorkflowActionIdentifier'].removeprefix('is.workflow.actions.')
        result = None
        if kind == 'downloadurl':
            result = index_data
        elif kind == 'detect.dictionary':
            result = resolve(q['WFInput'])
        elif kind == 'getvalueforkey':
            source = resolve(q['WFInput'])
            result = source.get(resolve(q['WFDictionaryKey'])) if isinstance(source, dict) else None
        elif kind == 'text.match':
            result = icu_findall(resolve(q['WFMatchTextPattern']), stringify(resolve(q['text'])))
        elif kind == 'gettext':
            result = resolve(q['WFTextActionText'])
        elif kind == 'setvariable':
            variables[q['WFVariableName']] = resolve(q['WFInput'])
        elif kind == 'conditional':
            mode = q['WFControlFlowMode']
            group = q['GroupingIdentifier']
            if mode == 0 and not bool(resolve(q['WFInput']['Variable'])):
                index = next(i for i in range(index+1,len(actions))
                    if actions[i]['WFWorkflowActionParameters'].get('GroupingIdentifier') == group
                    and actions[i]['WFWorkflowActionParameters'].get('WFControlFlowMode') in (1,2))
            elif mode == 1:
                index = next(i for i in range(index+1,len(actions))
                    if actions[i]['WFWorkflowActionParameters'].get('GroupingIdentifier') == group
                    and actions[i]['WFWorkflowActionParameters'].get('WFControlFlowMode') == 2)
        elif kind == 'url':
            return resolve(q['WFURL'])
        elif kind == 'showresult':
            return None
        else:
            raise AssertionError(('Unexpected lookup action',kind))
        outputs[q['UUID']] = result
        index += 1
    raise AssertionError('Lookup did not terminate')


for key, url in cache['guides'].items():
    assert evaluate_lookup(cache, key) == url
date_values = evaluate_date_actions(date(2026, 11, 14))
selection_keys = []
for index, action in enumerate(actions[:-1]):
    if action['WFWorkflowActionIdentifier'].endswith('.gettext') and actions[index+1]['WFWorkflowActionParameters'].get('WFVariableName') == 'Guide Lookup Key':
        state = action['WFWorkflowActionParameters']['WFTextActionText']['Value']
        assert len(state['attachmentsByRange']) == 1
        reference = next(iter(state['attachmentsByRange'].values()))
        key = state['string'].replace('\ufffc', date_values[reference['VariableName']])
        assert evaluate_lookup(cache, key) == cache['guides'][key]
        selection_keys.append(key)
assert set(selection_keys) == {'coming:November-2026','leaving:November-2026',
                               'coming:December-2026','leaving:December-2026'}
assert evaluate_lookup(cache, 'coming:January-2099') is None
assert evaluate_lookup({'guides':{'coming:November-2026':'https://evil.test/'}}, 'coming:November-2026') is None
assert evaluate_lookup({'guides':{}}, 'coming:November-2026') is None

report = {'result': 'passed', 'actions': len(actions), 'author_comment_only': comments == [0],
          'text_token_states_checked': token_count, 'embedded_cards_checked': card_count,
          'unique_and_prior_action_references': True, 'balanced_control_flow': True,
          'month_rollover_cases': 4, 'feed_index_fixtures': 'passed',
          'last_good_guides_preserved_on_feed_failure': True,
          'emitted_lookup_cases': len(cache['guides']) + 3,
          'indexed_guides': cache['guides'], 'feed_fetch_errors': cache.get('errors', {}),
          'native_rss_article_conversion_removed': True,
          'update_link_validation': 'passed', 'native_iphone_execution': 'not performed',
          'unsigned': True, 'live_feeds': 'not requested'}

if '--live' in sys.argv:
    url = 'https://raw.githubusercontent.com/surfkraken/Netflix-and-Chill/main/netflix-guides.json'
    with urllib.request.urlopen(url, timeout=25) as response:
        remote = json.load(response)
    assert remote['schema'] == 1 and remote['region'] == 'US'
    for key, target in cache['guides'].items():
        assert evaluate_lookup(remote, key) == target
    report['live_feeds'] = 'Live GitHub guide index verified against all local guide links'

(ROOT/'dist/verification.json').write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n')
print(json.dumps(report, indent=2, ensure_ascii=False))
