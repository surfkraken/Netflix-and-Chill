"""Exercise emitted patterns with ICU, the regex family used by Foundation."""
import ctypes as C
import ctypes.util
import re


def findall(pattern, source):
    library = ctypes.util.find_library('icui18n')
    if not library:
        return re.findall(pattern.replace(r'\z', r'\Z'), source)
    lib = C.CDLL(library)
    suffix = library.rsplit('.', 1)[-1]
    def api(name, result, args):
        fn = getattr(lib, name + '_' + suffix)
        fn.restype, fn.argtypes = result, args
        return fn
    status = C.c_int32(0)
    open_re = api('uregex_open', C.c_void_p,
                  [C.c_void_p, C.c_int32, C.c_uint32, C.c_void_p, C.POINTER(C.c_int32)])
    set_text = api('uregex_setText', None, [C.c_void_p, C.c_void_p, C.c_int32, C.POINTER(C.c_int32)])
    find_next = api('uregex_findNext', C.c_int8, [C.c_void_p, C.POINTER(C.c_int32)])
    start = api('uregex_start', C.c_int32, [C.c_void_p, C.c_int32, C.POINTER(C.c_int32)])
    end = api('uregex_end', C.c_int32, [C.c_void_p, C.c_int32, C.POINTER(C.c_int32)])
    close = api('uregex_close', None, [C.c_void_p])
    pb, sb = pattern.encode('utf-16-le'), source.encode('utf-16-le')
    p, s = C.create_string_buffer(pb), C.create_string_buffer(sb)
    regex = open_re(p, len(pb)//2, 0, None, C.byref(status))
    assert regex and status.value <= 0, ('ICU compile error', status.value, pattern)
    result = []
    try:
        set_text(regex, s, len(sb)//2, C.byref(status))
        while find_next(regex, C.byref(status)):
            a, b = start(regex, 0, C.byref(status)), end(regex, 0, C.byref(status))
            result.append(sb[a*2:b*2].decode('utf-16-le'))
        assert status.value <= 0, ('ICU match error', status.value)
    finally:
        close(regex)
    return result
