#!/usr/bin/env python3
"""Build the unsigned Netflix & Chill Apple Shortcut from native actions."""
from __future__ import annotations

import base64
import contextlib
import io
import json
from pathlib import Path
import plistlib
import re
import uuid

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent
NAME = 'Netflix & Chill'
VERSION = '1.0'
BUILD = 100
REPO = 'https://github.com/surfkraken/Netflix-and-Chill'
MANIFEST = 'https://raw.githubusercontent.com/surfkraken/Netflix-and-Chill/main/latest.json'
ARRIVALS = 'https://www.whats-on-netflix.com/coming-soon/feed/'
DEPARTURES = 'https://www.whats-on-netflix.com/leaving-soon/feed/'
MONTHS = dict(enumerate(('January February March April May June July August '
                         'September October November December').split(), 1))
P = 'is.workflow.actions.'


def token(value):
    return {'Value': value, 'WFSerializationType': 'WFTextTokenAttachment'}


def var(name):
    return token({'Type': 'Variable', 'VariableName': name})


def text(*parts):
    result, refs = '', {}
    for part in parts:
        offset = len(result.encode('utf-16-le')) // 2
        if isinstance(part, dict):
            if part.get('WFSerializationType') == 'WFTextTokenString':
                for key, value in part['Value']['attachmentsByRange'].items():
                    pos, length = map(int, re.findall(r'\d+', key))
                    refs['{%d, %d}' % (offset + pos, length)] = value
                result += part['Value']['string']
            else:
                refs['{%d, 1}' % offset] = part['Value']
                result += '\ufffc'
        else:
            result += str(part)
    return ({'Value': {'string': result, 'attachmentsByRange': refs},
             'WFSerializationType': 'WFTextTokenString'} if refs else result)


OUTPUTS = {'gettext': 'Text', 'number': 'Number', 'date': 'Date',
           'format.date': 'Formatted Date', 'math': 'Calculation Result',
           'getvalueforkey': 'Dictionary Value', 'detect.dictionary': 'Dictionary',
           'text.match': 'Matches', 'setitemname': 'Renamed Item',
           'detect.contacts': 'Contacts', 'choosefromlist': 'Chosen Item',
           'properties.contacts': 'Notes', 'rss': 'Items from RSS Feed',
           'properties.articles': 'Article Details', 'downloadurl': 'Contents of URL',
           'url': 'URL'}


class Builder:
    def __init__(self):
        self.actions = []
        self.depth = 0

    def action(self, ident, **params):
        params['UUID'] = str(uuid.uuid4()).upper()
        self.actions.append({'WFWorkflowActionIdentifier': P + ident,
                             'WFWorkflowActionParameters': params})
        return token({'Type': 'ActionOutput', 'OutputUUID': params['UUID'],
                      'OutputName': OUTPUTS.get(ident, 'Result')})

    def txt(self, *parts):
        return self.action('gettext', WFTextActionText=text(*parts))

    def set(self, name, value):
        if not isinstance(value, dict):
            value = self.txt(value)
        self.action('setvariable', WFVariableName=name, WFInput=value)
        return var(name)

    def empty(self, name):
        return self.set(name, self.action('nothing'))

    def match(self, source, pattern):
        return self.action('text.match', text=text(source), WFMatchTextPattern=text(pattern),
                           WFMatchTextCaseSensitive=True)

    def show(self, *parts):
        self.action('showresult', Text=text(*parts))

    @contextlib.contextmanager
    def iff(self, source, condition=100, value=None):
        group = str(uuid.uuid4()).upper()
        params = dict(GroupingIdentifier=group, WFControlFlowMode=0,
                      WFCondition=condition, WFInput={'Type': 'Variable', 'Variable': source})
        if condition in (0, 1, 2, 3):
            params['WFNumberValue'] = value if isinstance(value, dict) else str(value)
        if condition == 4:
            params['WFConditionalActionString'] = value
        self.action('conditional', **params)
        outer = self

        class Branch:
            def otherwise(self):
                outer.action('conditional', GroupingIdentifier=group, WFControlFlowMode=1)

        yield Branch()
        self.action('conditional', GroupingIdentifier=group, WFControlFlowMode=2)

    @contextlib.contextmanager
    def repeat(self, source=None, times=None):
        group = str(uuid.uuid4()).upper()
        ident = 'repeat.each' if source is not None else 'repeat.count'
        params = dict(GroupingIdentifier=group, WFControlFlowMode=0)
        params['WFInput' if source is not None else 'WFRepeatCount'] = source if source is not None else times
        self.action(ident, **params)
        self.depth += 1
        suffix = '' if self.depth == 1 else ' ' + str(self.depth)
        yield var('Repeat Item' + suffix), var('Repeat Index' + suffix)
        self.action('nothing')
        self.action(ident, GroupingIdentifier=group, WFControlFlowMode=2)
        self.depth -= 1


def icon(kind):
    scale = 3
    im = Image.new('RGBA', (192 * scale, 192 * scale), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    def line(points, width=8, fill='#fff8ee'):
        d.line([(x*scale, y*scale) for x, y in points], fill=fill,
               width=width*scale, joint='curve')
    def rect(box, radius=9, fill=None, outline='#fff8ee', width=7):
        d.rounded_rectangle(tuple(v*scale for v in box), radius*scale, fill=fill,
                            outline=outline, width=width*scale)
    d.ellipse((8*scale, 8*scale, 184*scale, 184*scale), fill='#b70f27')
    d.ellipse((17*scale, 13*scale, 175*scale, 171*scale), fill='#e71938')
    if kind == 'arrivals':
        rect((43, 78, 149, 141), radius=7)
        rect((43, 50, 149, 78), radius=3, fill='#fff8ee', outline=None)
        for x in (51, 81, 111):
            line([(x, 74), (x+16, 54)], width=7, fill='#b70f27')
        d.polygon([(83*scale, 94*scale), (83*scale, 125*scale), (113*scale, 110*scale)], fill='#fff8ee')
    elif kind == 'leaving':
        rect((42, 57, 140, 133), radius=8)
        line([(66, 78), (113, 78)], width=6)
        d.ellipse((92*scale, 93*scale, 156*scale, 157*scale), fill='#b70f27', outline='#fff8ee', width=6*scale)
        line([(124, 108), (124, 126), (138, 134)], width=6)
    elif kind == 'calendar':
        rect((48, 54, 145, 146))
        line([(49, 82), (142, 82)], width=6)
        for x in (72, 121):
            line([(x, 43), (x, 65)], width=8)
        line([(72, 115), (119, 115)], width=7)
        line([(105, 101), (119, 115), (105, 129)], width=7)
    elif kind == 'info':
        d.ellipse((50*scale, 50*scale, 142*scale, 142*scale), outline='#fff8ee', width=7*scale)
        d.ellipse((91*scale, 72*scale, 101*scale, 82*scale), fill='#fff8ee')
        line([(96, 96), (96, 123)], width=9)
    elif kind == 'update':
        d.arc((48*scale, 48*scale, 145*scale, 145*scale), 45, 305, fill='#fff8ee', width=8*scale)
        line([(130, 51), (145, 70), (122, 74)], width=8)
        line([(96, 76), (96, 117)], width=7)
        line([(81, 103), (96, 118), (111, 103)], width=7)
    elif kind == 'back':
        line([(137, 97), (58, 97)], width=9)
        line([(85, 70), (58, 97), (85, 124)], width=9)
    else:
        rect((50, 47, 103, 147), radius=5)
        line([(82, 97), (147, 97)], width=8)
        line([(126, 76), (147, 97), (126, 118)], width=8)
    out = io.BytesIO()
    im.resize((192, 192), Image.Resampling.LANCZOS).save(out, format='PNG', optimize=True)
    return out.getvalue()


ICONS = {k: icon(k) for k in ('arrivals', 'leaving', 'calendar', 'info', 'update', 'back', 'quit')}


def vc_escape(value):
    return value.replace('\\', '\\\\').replace('\n', '\\n').replace(';', '\\;').replace(',', '\\,')


def vcard(rows):
    cards = []
    for title, subtitle, route, image in rows:
        photo = base64.b64encode(ICONS[image]).decode('ascii')
        cards.append('\n'.join(('BEGIN:VCARD', 'VERSION:3.0',
                                'N:;' + vc_escape(title) + ';;;', 'FN:' + vc_escape(title),
                                'ORG:' + vc_escape(subtitle), 'NOTE:' + route,
                                'PHOTO;ENCODING=b;TYPE=PNG:' + photo, 'END:VCARD')))
    return '\n'.join(cards)


MAIN = [('Coming This Month', 'Fresh arrivals. Your couch is calling.', 'coming', 'arrivals'),
        ('Last Call', 'Watch before Netflix changes the locks.', 'leaving', 'leaving'),
        ('Next Month', 'More reasons to cancel your plans.', 'next', 'calendar'),
        ('About & Updates', 'Created by SurfKraken. Built for the couch.', 'about', 'info'),
        ('Quit', 'Back to real life. Allegedly.', 'quit', 'quit')]
NEXT = [('Coming Next Month', 'Get a head start on doing absolutely nothing.', 'coming', 'arrivals'),
        ('Leaving Next Month', 'A little warning before the breakup.', 'leaving', 'leaving'),
        ('Back', 'Return to this month.', 'back', 'back')]
ABOUT = [('About Netflix & Chill', 'The credits, the source, and how it works.', 'credits', 'info'),
         ('Check for Updates', 'Keep the shortcut fresh.', 'updates', 'update'),
         ('Back', 'Return to the main menu.', 'back', 'back')]


def menu(b, rows, prompt, destination):
    source = b.action('setitemname', WFInput=b.txt(vcard(rows)),
                      WFName='Netflix-and-Chill-Menu.vcf', WFDontIncludeFileExtension=False)
    contacts = b.action('detect.contacts', WFInput=source)
    choice = b.action('choosefromlist', WFInput=contacts,
                      WFChooseFromListActionPrompt=text(prompt),
                      WFChooseFromListActionSelectMultiple=False)
    b.set(destination, b.action('properties.contacts', WFInput=choice, WFContentItemPropertyName='Notes'))


def update_check(b, manual=False):
    b.set('Update Status', 'The update information is unavailable. Try again later.')
    response = b.action('downloadurl', WFURL=MANIFEST, WFHTTPMethod='GET')
    manifest = b.action('detect.dictionary', WFInput=response)
    raw_build = b.action('getvalueforkey', WFInput=manifest, WFGetDictionaryValueType='Value',
                         WFDictionaryKey='build')
    valid_build = b.match(raw_build, r'\A[0-9]{1,9}\z')
    with b.iff(valid_build):
        latest = b.action('number', WFNumberActionNumber=text(valid_build))
        b.set('Update Status', f'You have the current release.\n\nNetflix & Chill\nVersion {VERSION} / Build {BUILD}')
        with b.iff(latest, 2, BUILD):
            b.set('Update Status', 'A newer build is listed, but its installation link is not ready yet.')
            raw_url = b.action('getvalueforkey', WFInput=manifest, WFGetDictionaryValueType='Value',
                               WFDictionaryKey='url')
            valid_url = b.match(raw_url, r'\Ahttps://www\.icloud\.com/shortcuts/[0-9a-fA-F]{32}/?\z')
            with b.iff(valid_url):
                menu(b, [('Install Update', 'Open the new release in Shortcuts.', 'install', 'update'),
                         ('Not Now', 'The couch can wait. Updates can too.', 'later', 'back')],
                     'Netflix & Chill\nAn update is available', 'Update Choice')
                with b.iff(var('Update Choice'), 4, 'install'):
                    b.action('openurl', WFInput=text(valid_url))
                    b.action('exit')
                b.set('Update Status', 'Update skipped. You can check again from About & Updates.')
    if manual:
        b.show(var('Update Status'))


def date_labels(b):
    now = b.action('date', WFDateActionMode='Current Date')
    month = b.action('format.date', WFDate=now, WFDateFormatStyle='Custom', WFDateFormat='M')
    year = b.action('format.date', WFDate=now, WFDateFormatStyle='Custom', WFDateFormat='yyyy')
    b.set('This Month Number', b.action('number', WFNumberActionNumber=text(month)))
    b.set('This Year', b.action('number', WFNumberActionNumber=text(year)))
    b.set('Next Month Number', b.action('math', WFInput=var('This Month Number'),
                                      WFMathOperation='+', WFMathOperand=1))
    b.set('Next Year', var('This Year'))
    with b.iff(var('Next Month Number'), 2, 12):
        b.set('Next Month Number', b.action('number', WFNumberActionNumber='1'))
        b.set('Next Year', b.action('math', WFInput=var('This Year'), WFMathOperation='+', WFMathOperand=1))
    months = b.action('detect.dictionary', WFInput=b.txt(json.dumps(MONTHS)))
    for prefix, number, year_var in [('This', 'This Month Number', 'This Year'),
                                     ('Next', 'Next Month Number', 'Next Year')]:
        name = b.action('getvalueforkey', WFInput=months, WFGetDictionaryValueType='Value',
                        WFDictionaryKey=text(var(number)))
        b.set(prefix + ' Month Label', b.txt(name, ' ', var(year_var)))


def select_guide(b, kind, month):
    b.set('Selected Feed', ARRIVALS if kind == 'coming' else DEPARTURES)
    b.set('Selected Category', ARRIVALS.removesuffix('feed/') if kind == 'coming'
          else DEPARTURES.removesuffix('feed/'))
    b.set('Selected Month', month)
    verb = 'Coming to' if kind == 'coming' else 'Leaving'
    b.set('Guide Title Pattern', b.txt(r'(?i)\A(?:Full List of )?What[\x{2019}\x27]s ', verb,
          r' Netflix in \Q', var('Selected Month'), r'\E\s*\z'))


def find_guide(b):
    b.empty('Guide URL')
    items = b.action('rss', WFRSSFeedURL=text(var('Selected Feed')), WFRSSItemQuantity=50)
    with b.repeat(source=items) as (item, _):
        with b.iff(var('Guide URL'), 101):
            title = b.action('properties.articles', WFInput=item, WFContentItemPropertyName='Title')
            match = b.match(title, var('Guide Title Pattern'))
            with b.iff(match):
                candidate = b.action('properties.articles', WFInput=item, WFContentItemPropertyName='URL')
                safe_url = b.match(candidate,
                    r'\Ahttps://www\.whats-on-netflix\.com/(?:coming-soon|leaving-soon)/[a-z0-9-]+/?\z')
                with b.iff(safe_url):
                    b.set('Guide URL', b.txt(safe_url))
    with b.iff(var('Guide URL')) as branch:
        url = b.action('url', WFURL=text(var('Guide URL')))
        b.action('showwebpage', WFInput=url, WFEnterSafariReader=False)
        branch.otherwise()
        b.show('The ', var('Selected Month'), ' guide was not found in the current feed.\n\n'
               'It may not be published yet, or it may have dropped out of the feed. '
               'The publisher keeps its latest guides on the page below.')
        menu(b, [('Open Latest Guides', 'Browse the publisher’s current coverage.', 'open', 'arrivals'),
                 ('Back', 'Return to Netflix & Chill.', 'back', 'back')],
             'Monthly guide unavailable', 'Fallback Choice')
        with b.iff(var('Fallback Choice'), 4, 'open'):
            url = b.action('url', WFURL=text(var('Selected Category')))
            b.action('showwebpage', WFInput=url, WFEnterSafariReader=False)


def build():
    b = Builder()
    b.action('comment', WFCommentActionText=(
        f'Netflix & Chill\nCreated by SurfKraken\nVersion {VERSION} / Build {BUILD}\n\n'
        'Monthly Netflix US arrivals and departures, with fresh guides from What’s on Netflix.\n'
        'Unofficial shortcut. Not affiliated with Netflix or What’s on Netflix.\n\n'
        f'Project and updates: {REPO}'))
    update_check(b)
    with b.repeat(times=999):
        date_labels(b)
        b.empty('Selected Feed')
        menu(b, MAIN, text('Netflix & Chill\nNetflix US • ', var('This Month Label')), 'Main Choice')
        with b.iff(var('Main Choice'), 4, 'quit'):
            b.action('exit')
        for kind in ('coming', 'leaving'):
            with b.iff(var('Main Choice'), 4, kind):
                select_guide(b, kind, var('This Month Label'))
        with b.iff(var('Main Choice'), 4, 'next'):
            menu(b, NEXT, text('Next Month\n', var('Next Month Label'), ' • Netflix US'), 'Next Choice')
            for kind in ('coming', 'leaving'):
                with b.iff(var('Next Choice'), 4, kind):
                    select_guide(b, kind, var('Next Month Label'))
        with b.iff(var('Main Choice'), 4, 'about'):
            menu(b, ABOUT, 'Netflix & Chill\nAbout & Updates', 'About Choice')
            with b.iff(var('About Choice'), 4, 'credits'):
                b.show(f'Netflix & Chill\nCreated by SurfKraken\nVersion {VERSION} / Build {BUILD}\n\n'
                       'Find what’s coming to and leaving Netflix in the US this month and next. '
                       'Dates are selected automatically.\n\n'
                       'Source: What’s on Netflix RSS feeds. Guides open inside the shortcut, '
                       'with the publisher’s artwork and credits intact. The feed has selected '
                       'banners and stills, not a poster for every title.\n\n'
                       'Schedules can change. Leaving dates may be the first unavailable day, '
                       'so watch before the listed date.\n\n'
                       'Internet required. The shortcut checks for updates each time it starts. '
                       'It opens a newer release for you to review and install.\n\n'
                       f'Unofficial. Not affiliated with Netflix or What’s on Netflix.\n{REPO}')
            with b.iff(var('About Choice'), 4, 'updates'):
                update_check(b, manual=True)
        with b.iff(var('Selected Feed')):
            find_guide(b)
    b.action('exit')
    workflow = {'WFWorkflowName': NAME, 'WFWorkflowClientVersion': '5203.0.1',
                'WFWorkflowMinimumClientVersion': 900, 'WFWorkflowMinimumClientVersionString': '900',
                'WFWorkflowHasOutputFallback': False, 'WFWorkflowHasShortcutInputVariables': False,
                'WFWorkflowIcon': {'WFWorkflowIconGlyphNumber': 59756, 'WFWorkflowIconStartColor': 4274264319},
                'WFWorkflowTypes': ['NCWidget', 'WFWorkflowTypeShowInSearch'],
                'WFQuickActionSurfaces': [], 'WFWorkflowImportQuestions': [],
                'WFWorkflowInputContentItemClasses': [], 'WFWorkflowOutputContentItemClasses': [],
                'WFWorkflowActions': b.actions}
    dist = ROOT / 'dist'
    dist.mkdir(exist_ok=True)
    path = dist / 'Netflix-and-Chill-unsigned.shortcut'
    path.write_bytes(plistlib.dumps(workflow, fmt=plistlib.FMT_XML, sort_keys=False))
    (ROOT / 'latest.json').write_text(json.dumps({'version': VERSION, 'build': BUILD,
        'url': '', 'release_notes': 'Initial release. Monthly Netflix US guides with vCard menus.'}, indent=2)+'\n')
    (dist / 'build-manifest.json').write_text(json.dumps({'name': NAME, 'version': VERSION,
        'build': BUILD, 'author': 'SurfKraken', 'actions': len(b.actions), 'signed': False,
        'update_manifest': MANIFEST, 'release_url_pending': True}, indent=2)+'\n')
    (ROOT / 'menu-preview.json').write_text(json.dumps({'main': MAIN, 'next': NEXT, 'about': ABOUT}, indent=2)+'\n')
    print(json.dumps({'path': str(path), 'actions': len(b.actions), 'bytes': path.stat().st_size}))
    return workflow


if __name__ == '__main__':
    build()
