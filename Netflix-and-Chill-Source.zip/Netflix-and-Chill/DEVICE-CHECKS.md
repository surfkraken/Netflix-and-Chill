# Netflix & Chill device checks

The delivered shortcut is unsigned. Sign it, import it, and run these checks before publishing the signed iCloud link.

1. Open the shortcut. Confirm the name, five main menu cards, artwork, and subtitles. The first and only comment action should contain the SurfKraken author information.
2. Choose Coming This Month. Confirm the guide is for the displayed month and Netflix US. Close the guide with Done and confirm the main menu returns.
3. Choose Last Call. Confirm the departures guide and return using Done.
4. Open Next Month. Test both arrivals and departures, then Back. An unpublished or missing guide should give a clear explanation and an optional source page.
5. Open About & Updates. Test About, Check for Updates, and Back. The current manifest should report the installed build as current.
6. Test Quit. Confirm the shortcut ends.
7. To test the update prompt locally, temporarily reduce the local comparison build below the remote build and supply a valid signed release URL in the remote manifest. Verify Install Update opens that release and Not Now continues. Restore the correct build afterward. Do not publish a test manifest that points to an unrelated shortcut.

Native network failures and system cancellation can stop a run. These checks verify real iPhone behavior that a Linux build environment cannot execute.
